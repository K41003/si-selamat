
<div class="flex flex-col sm:flex-row sm:items-center gap-1 sm:gap-2">
    <span class="w-44 sm:w-52 shrink-0 flex items-center justify-between"><span><?php echo e($label); ?></span><span class="hidden sm:inline">:</span></span>
    <div class="flex-1 font-sans">
        <input type="<?php echo e($type ?? 'text'); ?>" name="data_isian[<?php echo e($key); ?>]" x-model="isian['<?php echo e($key); ?>']"
               placeholder="<?php echo e($placeholder ?? ''); ?>" class="field bg-white">
    </div>
</div>
<?php /**PATH C:\7SIA3\Project_Web\si-selamat\si-selamat\resources\views/surat/_row.blade.php ENDPATH**/ ?>