<?php $__env->startSection('title', 'Log Aktivitas'); ?>

<?php $__env->startSection('content'); ?>
<?php
    $tabs = [
        ''      => 'Semua',
        'surat' => 'Surat',
        'warga' => 'Warga',
        'nik'   => 'Akses NIK',
        'akses' => 'Login / Logout',
    ];

    // Hitung per kategori untuk label tab
    $counts = [
        ''      => \App\Models\ActivityLog::count(),
        'surat' => \App\Models\ActivityLog::whereIn('aksi', ['Simpan Draft Surat','Buat Permohonan Surat','Perbarui Draft Surat','Pengajuan Surat ke Kades','Hapus Surat','Validasi Surat Disetujui','Validasi Surat Ditolak'])->count(),
        'warga' => \App\Models\ActivityLog::whereIn('aksi', ['Tambah Data Warga','Update Data Warga','Hapus Data Warga','Import Data Warga CSV'])->count(),
        'nik'   => \App\Models\ActivityLog::whereIn('aksi', ['Buka NIK Warga'])->count(),
        'akses' => \App\Models\ActivityLog::whereIn('aksi', ['Login Sistem','Logout Sistem'])->count(),
    ];
?>

<div class="space-y-6">
    <?php if (isset($component)) { $__componentOriginalf8d4ea307ab1e58d4e472a43c8548d8e = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf8d4ea307ab1e58d4e472a43c8548d8e = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.page-header','data' => ['title' => 'Log Aktivitas & Audit Trail','subtitle' => 'Rekam jejak seluruh tindakan staf dan kepala desa pada sistem.']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('page-header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Log Aktivitas & Audit Trail','subtitle' => 'Rekam jejak seluruh tindakan staf dan kepala desa pada sistem.']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf8d4ea307ab1e58d4e472a43c8548d8e)): ?>
<?php $attributes = $__attributesOriginalf8d4ea307ab1e58d4e472a43c8548d8e; ?>
<?php unset($__attributesOriginalf8d4ea307ab1e58d4e472a43c8548d8e); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf8d4ea307ab1e58d4e472a43c8548d8e)): ?>
<?php $component = $__componentOriginalf8d4ea307ab1e58d4e472a43c8548d8e; ?>
<?php unset($__componentOriginalf8d4ea307ab1e58d4e472a43c8548d8e); ?>
<?php endif; ?>

    <?php if (isset($component)) { $__componentOriginal53747ceb358d30c0105769f8471417f6 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal53747ceb358d30c0105769f8471417f6 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.card','data' => ['padded' => false,'class' => 'overflow-hidden']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['padded' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(false),'class' => 'overflow-hidden']); ?>

        
        <nav aria-label="Filter kategori log" class="flex gap-2 overflow-x-auto border-b border-line p-4">
            <?php $__currentLoopData = $tabs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php $aktif = ($jenis ?? '') === $val; ?>
            <a href="<?php echo e(route('logs.index', array_merge(request()->only('q', 'role'), ['jenis' => $val]))); ?>"
               <?php if($aktif): ?> aria-current="page" <?php endif; ?>
               class="pill-tab">
                <?php echo e($label); ?>

                <span class="font-normal tabular-nums <?php echo e($aktif ? 'text-white' : 'text-ink-600'); ?>"><?php echo e($counts[$val]); ?></span>
            </a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </nav>

        
        <form method="GET" action="<?php echo e(route('logs.index')); ?>" role="search" aria-label="Cari log aktivitas"
              class="flex flex-col gap-2 border-b border-line p-4 sm:flex-row">
            <input type="hidden" name="jenis" value="<?php echo e($jenis ?? ''); ?>">

            
            <div class="sm:w-52">
                <label class="sr-only" for="filter-role">Filter peran</label>
                <select id="filter-role" name="role" class="field">
                    <option value="">Semua peran</option>
                    <option value="Staff Pelayanan" <?php echo e(($role ?? '') === 'Staff Pelayanan' ? 'selected' : ''); ?>>Staff Pelayanan</option>
                    <option value="Kepala Desa"     <?php echo e(($role ?? '') === 'Kepala Desa'     ? 'selected' : ''); ?>>Kepala Desa</option>
                </select>
            </div>

            
            <div class="relative flex-1">
                <label for="cari-log" class="sr-only">Cari log aktivitas</label>
                <?php if (isset($component)) { $__componentOriginalce262628e3a8d44dc38fd1f3965181bc = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.icon','data' => ['name' => 'search','class' => 'pointer-events-none absolute left-3.5 top-1/2 size-4 -translate-y-1/2 text-ink-600']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'search','class' => 'pointer-events-none absolute left-3.5 top-1/2 size-4 -translate-y-1/2 text-ink-600']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $attributes = $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $component = $__componentOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?>
                <input id="cari-log" type="search" name="q" value="<?php echo e($search ?? ''); ?>"
                       placeholder="Cari nama petugas, jenis tindakan, atau deskripsi…"
                       class="field pl-10">
            </div>

            <div class="flex gap-2">
                <button type="submit" class="btn btn-primary">Cari</button>
                <?php if(!empty($search) || !empty($role)): ?>
                <a href="<?php echo e(route('logs.index', ['jenis' => $jenis ?? ''])); ?>" class="btn btn-ghost">Reset</a>
                <?php endif; ?>
            </div>
        </form>

        
        <?php if($logs->isEmpty()): ?>
            <?php if (isset($component)) { $__componentOriginal074a021b9d42f490272b5eefda63257c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal074a021b9d42f490272b5eefda63257c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.empty-state','data' => ['icon' => !empty($search) ? 'search' : 'clock','title' => 'Tidak ada log yang ditemukan','description' => !empty($search) ? 'Coba kata kunci lain atau hapus pencarian.' : 'Belum ada aktivitas pada kategori ini.']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('empty-state'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['icon' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(!empty($search) ? 'search' : 'clock'),'title' => 'Tidak ada log yang ditemukan','description' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(!empty($search) ? 'Coba kata kunci lain atau hapus pencarian.' : 'Belum ada aktivitas pada kategori ini.')]); ?>
                <?php if(!empty($search)): ?>
                <a href="<?php echo e(route('logs.index', ['jenis' => $jenis ?? ''])); ?>" class="btn btn-secondary">Hapus pencarian</a>
                <?php endif; ?>
             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal074a021b9d42f490272b5eefda63257c)): ?>
<?php $attributes = $__attributesOriginal074a021b9d42f490272b5eefda63257c; ?>
<?php unset($__attributesOriginal074a021b9d42f490272b5eefda63257c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal074a021b9d42f490272b5eefda63257c)): ?>
<?php $component = $__componentOriginal074a021b9d42f490272b5eefda63257c; ?>
<?php unset($__componentOriginal074a021b9d42f490272b5eefda63257c); ?>
<?php endif; ?>
        <?php else: ?>
            <?php if (isset($component)) { $__componentOriginalc8463834ba515134d5c98b88e1a9dc03 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalc8463834ba515134d5c98b88e1a9dc03 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.data-table','data' => ['caption' => 'Log aktivitas dan audit trail']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('data-table'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['caption' => 'Log aktivitas dan audit trail']); ?>
                 <?php $__env->slot('head', null, []); ?> 
                    <tr>
                        <th scope="col" class="w-44">Waktu</th>
                        <th scope="col">Petugas</th>
                        <th scope="col">Tindakan</th>
                        <th scope="col">Deskripsi</th>
                    </tr>
                 <?php $__env->endSlot(); ?>

                <?php $__currentLoopData = $logs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $log): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr class="hover:bg-canvas/60">

                    
                    <td class="whitespace-nowrap align-top">
                        <time datetime="<?php echo e($log->created_at->toIso8601String()); ?>"
                              class="block tabular-nums text-ink-900">
                            <?php echo e($log->created_at->format('d/m/Y H:i:s')); ?>

                        </time>
                        <span class="text-xs text-ink-600"><?php echo e($log->created_at->diffForHumans()); ?></span>
                    </td>

                    
                    <td class="whitespace-nowrap align-top">
                        <p class="font-medium text-ink-900"><?php echo e($log->user_name); ?></p>
                        <?php $isKades = $log->user_role === 'Kepala Desa'; ?>
                        <span class="inline-flex items-center gap-1.5 whitespace-nowrap rounded-full px-2.5 py-1 text-xs font-semibold
                                     <?php echo e($isKades ? 'bg-warning-100 text-warning-800' : 'bg-info-100 text-info-800'); ?>">
                            <span class="size-1.5 rounded-full bg-current" aria-hidden="true"></span>
                            <?php echo e($log->user_role); ?>

                        </span>
                    </td>

                    
                    <td class="whitespace-nowrap align-top">
                        <?php
                            $aksiLower = strtolower($log->aksi);
                            $tone = match(true) {
                                str_contains($aksiLower, 'nik')                                      => 'bg-danger-100 text-danger-800',
                                str_contains($aksiLower, 'warga')                                    => 'bg-info-100 text-info-800',
                                str_contains($aksiLower, 'surat')                                    => 'bg-success-100 text-success-800',
                                str_contains($aksiLower, 'login') || str_contains($aksiLower, 'logout') => 'bg-canvas text-ink-700',
                                default                                                              => 'bg-canvas text-ink-700',
                            };
                        ?>
                        <span class="inline-flex items-center gap-1.5 whitespace-nowrap rounded-full px-2.5 py-1 text-xs font-semibold <?php echo e($tone); ?>">
                            <span class="size-1.5 rounded-full bg-current" aria-hidden="true"></span>
                            <?php echo e($log->aksi); ?>

                        </span>
                    </td>

                    
                    <td class="align-top text-ink-700">
                        <?php echo e($log->deskripsi); ?>

                    </td>

                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalc8463834ba515134d5c98b88e1a9dc03)): ?>
<?php $attributes = $__attributesOriginalc8463834ba515134d5c98b88e1a9dc03; ?>
<?php unset($__attributesOriginalc8463834ba515134d5c98b88e1a9dc03); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc8463834ba515134d5c98b88e1a9dc03)): ?>
<?php $component = $__componentOriginalc8463834ba515134d5c98b88e1a9dc03; ?>
<?php unset($__componentOriginalc8463834ba515134d5c98b88e1a9dc03); ?>
<?php endif; ?>

            <?php if($logs->hasPages()): ?>
            <div class="border-t border-line p-4">
                <?php echo e($logs->links()); ?>

            </div>
            <?php endif; ?>
        <?php endif; ?>

     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal53747ceb358d30c0105769f8471417f6)): ?>
<?php $attributes = $__attributesOriginal53747ceb358d30c0105769f8471417f6; ?>
<?php unset($__attributesOriginal53747ceb358d30c0105769f8471417f6); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal53747ceb358d30c0105769f8471417f6)): ?>
<?php $component = $__componentOriginal53747ceb358d30c0105769f8471417f6; ?>
<?php unset($__componentOriginal53747ceb358d30c0105769f8471417f6); ?>
<?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\7SIA3\Project_Web\si-selamat\si-selamat\resources\views/logs/index.blade.php ENDPATH**/ ?>