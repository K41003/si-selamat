
<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['warga']));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['warga']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<?php if (! $__env->hasRenderedOnce('6254c313-f83c-4e8e-9896-f082c01c0be1')): $__env->markAsRenderedOnce('6254c313-f83c-4e8e-9896-f082c01c0be1'); ?>
<script>
document.addEventListener('alpine:init', () => {
    Alpine.data('nikReveal', (url) => ({
        nik: null, loading: false, error: '', timer: null,
        async tampil() {
            this.loading = true; this.error = '';
            try {
                const meta = document.querySelector('meta[name="csrf-token"]');
                const res = await fetch(url, {
                    method: 'POST',
                    credentials: 'same-origin',
                    headers: {
                        'Accept': 'application/json',
                        'X-Requested-With': 'XMLHttpRequest',
                        'X-CSRF-TOKEN': meta ? meta.content : '',
                    },
                });
                if (!res.ok) throw new Error('HTTP ' + res.status);
                const data = await res.json();
                this.nik = data.nik;
                clearTimeout(this.timer);
                this.timer = setTimeout(() => this.sembunyikan(), 30000);
            } catch (e) {
                this.error = 'Gagal menampilkan NIK. Muat ulang halaman lalu coba lagi.';
            }
            this.loading = false;
        },
        sembunyikan() { this.nik = null; clearTimeout(this.timer); },
    }));
});
</script>
<?php endif; ?>

<div x-data="nikReveal(<?php echo \Illuminate\Support\Js::from(route('warga.nik', $warga))->toHtml() ?>)" class="flex flex-wrap items-center gap-x-3 gap-y-1">
    <span class="font-mono text-ink-900">
        <span x-show="!nik"><?php echo e($warga->masked_nik); ?></span>
        <span x-show="nik" x-cloak x-text="nik"></span>
    </span>
    <button type="button" class="btn btn-secondary btn-sm" x-show="!nik" @click="tampil()" :disabled="loading">
        <?php if (isset($component)) { $__componentOriginalce262628e3a8d44dc38fd1f3965181bc = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.icon','data' => ['name' => 'eye','class' => 'size-4']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'eye','class' => 'size-4']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $attributes = $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $component = $__componentOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?> <span x-text="loading ? 'Memuat…' : 'Tampilkan NIK'"></span>
    </button>
    <button type="button" class="btn btn-ghost btn-sm" x-show="nik" x-cloak @click="sembunyikan()">Sembunyikan</button>
    <span x-show="nik" x-cloak class="text-sm text-ink-600">Otomatis disembunyikan dalam 30 detik. Pembukaan NIK dicatat.</span>
    <span x-show="error" x-cloak x-text="error" class="text-sm font-medium text-danger-700"></span>
    <span class="sr-only" role="status" aria-live="polite" x-text="nik ? 'NIK ditampilkan' : ''"></span>
</div>
<?php /**PATH C:\7SIA3\Project_Web\si-selamat\si-selamat\resources\views/components/nik-reveal.blade.php ENDPATH**/ ?>