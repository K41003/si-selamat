<?php if($paginator->hasPages()): ?>
    <nav role="navigation" aria-label="<?php echo e(__('Navigasi Halaman')); ?>" class="flex items-center justify-between">
        <div class="flex flex-1 justify-between sm:hidden">
            <?php if($paginator->onFirstPage()): ?>
                <span class="inline-flex min-h-9 items-center rounded-control border border-line bg-canvas/60 px-3.5 text-sm font-medium text-ink-500 cursor-not-allowed">
                    &laquo; Sebelumnya
                </span>
            <?php else: ?>
                <a href="<?php echo e($paginator->previousPageUrl()); ?>" rel="prev" class="inline-flex min-h-9 items-center rounded-control border border-line bg-surface px-3.5 text-sm font-medium text-ink-700 hover:bg-canvas hover:text-ink-900 transition-colors">
                    &laquo; Sebelumnya
                </a>
            <?php endif; ?>

            <?php if($paginator->hasMorePages()): ?>
                <a href="<?php echo e($paginator->nextPageUrl()); ?>" rel="next" class="inline-flex min-h-9 items-center rounded-control border border-line bg-surface px-3.5 text-sm font-medium text-ink-700 hover:bg-canvas hover:text-ink-900 transition-colors">
                    Berikutnya &raquo;
                </a>
            <?php else: ?>
                <span class="inline-flex min-h-9 items-center rounded-control border border-line bg-canvas/60 px-3.5 text-sm font-medium text-ink-500 cursor-not-allowed">
                    Berikutnya &raquo;
                </span>
            <?php endif; ?>
        </div>

        <div class="hidden sm:flex sm:flex-1 sm:items-center sm:justify-between">
            <div>
                <p class="text-sm text-ink-600">
                    Menampilkan
                    <?php if($paginator->firstItem()): ?>
                        <span class="font-semibold text-ink-900"><?php echo e($paginator->firstItem()); ?></span>
                        sampai
                        <span class="font-semibold text-ink-900"><?php echo e($paginator->lastItem()); ?></span>
                    <?php else: ?>
                        <?php echo e($paginator->count()); ?>

                    <?php endif; ?>
                    dari
                    <span class="font-semibold text-ink-900"><?php echo e($paginator->total()); ?></span>
                    data
                </p>
            </div>

            <div>
                <span class="inline-flex rounded-control border border-line shadow-xs overflow-hidden">
                    
                    <?php if($paginator->onFirstPage()): ?>
                        <span aria-disabled="true" aria-label="Sebelumnya">
                            <span class="inline-flex min-h-9 items-center border-r border-line bg-canvas/60 px-3 text-sm text-ink-500 cursor-not-allowed" aria-hidden="true">
                                <svg class="size-4" fill="currentColor" viewBox="0 0 20 20">
                                    <path fill-rule="evenodd" d="M12.707 5.293a1 1 0 010 1.414L9.414 10l3.293 3.293a1 1 0 01-1.414 1.414l-4-4a1 1 0 010-1.414l4-4a1 1 0 011.414 0z" clip-rule="evenodd" />
                                </svg>
                            </span>
                        </span>
                    <?php else: ?>
                        <a href="<?php echo e($paginator->previousPageUrl()); ?>" rel="prev" class="inline-flex min-h-9 items-center border-r border-line bg-surface px-3 text-sm text-ink-700 hover:bg-canvas hover:text-ink-900 transition-colors" aria-label="Sebelumnya">
                            <svg class="size-4" fill="currentColor" viewBox="0 0 20 20">
                                <path fill-rule="evenodd" d="M12.707 5.293a1 1 0 010 1.414L9.414 10l3.293 3.293a1 1 0 01-1.414 1.414l-4-4a1 1 0 010-1.414l4-4a1 1 0 011.414 0z" clip-rule="evenodd" />
                            </svg>
                        </a>
                    <?php endif; ?>

                    
                    <?php $__currentLoopData = $elements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $element): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        
                        <?php if(is_string($element)): ?>
                            <span aria-disabled="true">
                                <span class="inline-flex min-h-9 items-center border-r border-line bg-surface px-3.5 text-sm font-medium text-ink-500 cursor-default"><?php echo e($element); ?></span>
                            </span>
                        <?php endif; ?>

                        
                        <?php if(is_array($element)): ?>
                            <?php $__currentLoopData = $element; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page => $url): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($page == $paginator->currentPage()): ?>
                                    <span aria-current="page">
                                        <span class="inline-flex min-h-9 items-center border-r border-line bg-brand-700 px-3.5 text-sm font-semibold text-white cursor-default"><?php echo e($page); ?></span>
                                    </span>
                                <?php else: ?>
                                    <a href="<?php echo e($url); ?>" class="inline-flex min-h-9 items-center border-r border-line bg-surface px-3.5 text-sm font-medium text-ink-700 hover:bg-canvas hover:text-ink-900 transition-colors" aria-label="Halaman <?php echo e($page); ?>">
                                        <?php echo e($page); ?>

                                    </a>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    
                    <?php if($paginator->hasMorePages()): ?>
                        <a href="<?php echo e($paginator->nextPageUrl()); ?>" rel="next" class="inline-flex min-h-9 items-center bg-surface px-3 text-sm text-ink-700 hover:bg-canvas hover:text-ink-900 transition-colors" aria-label="Berikutnya">
                            <svg class="size-4" fill="currentColor" viewBox="0 0 20 20">
                                <path fill-rule="evenodd" d="M7.293 14.707a1 1 0 010-1.414L10.586 10 7.293 6.707a1 1 0 011.414-1.414l4 4a1 1 0 010 1.414l-4 4a1 1 0 01-1.414 0z" clip-rule="evenodd" />
                            </svg>
                        </a>
                    <?php else: ?>
                        <span aria-disabled="true" aria-label="Berikutnya">
                            <span class="inline-flex min-h-9 items-center bg-canvas/60 px-3 text-sm text-ink-500 cursor-not-allowed" aria-hidden="true">
                                <svg class="size-4" fill="currentColor" viewBox="0 0 20 20">
                                    <path fill-rule="evenodd" d="M7.293 14.707a1 1 0 010-1.414L10.586 10 7.293 6.707a1 1 0 011.414-1.414l4 4a1 1 0 010 1.414l-4 4a1 1 0 01-1.414 0z" clip-rule="evenodd" />
                                </svg>
                            </span>
                        </span>
                    <?php endif; ?>
                </span>
            </div>
        </div>
    </nav>
<?php endif; ?>
<?php /**PATH C:\7SIA3\Project_Web\si-selamat\si-selamat\resources\views/vendor/pagination/tailwind.blade.php ENDPATH**/ ?>