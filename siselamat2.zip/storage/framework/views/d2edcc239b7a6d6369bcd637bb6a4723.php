<table class="bio in">
    <?php $__currentLoopData = $rows; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $label => $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr><td class="l"><?php echo e($label); ?></td><td class="c">:</td><td><?php echo e($val); ?></td></tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>
<?php /**PATH C:\7SIA3\Project_Web\si-selamat\si-selamat\resources\views/surat/templates/_bio.blade.php ENDPATH**/ ?>