
<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['eyebrow' => null, 'title', 'subtitle' => null]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['eyebrow' => null, 'title', 'subtitle' => null]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>
<div>
    <?php if($eyebrow): ?><p class="text-base text-brand-600"><?php echo e($eyebrow); ?></p><?php endif; ?>
    <h1 class="mt-0.5 break-words text-display font-extrabold tracking-tight text-brand-700 sm:text-[2.25rem] sm:leading-[2.75rem]"><?php echo e($title); ?></h1>
    <?php if($subtitle): ?><p class="mt-1.5 max-w-2xl text-sm text-ink-600"><?php echo e($subtitle); ?></p><?php endif; ?>
</div>
<?php /**PATH C:\7SIA3\Project_Web\si-selamat\si-selamat\resources\views/components/greeting.blade.php ENDPATH**/ ?>