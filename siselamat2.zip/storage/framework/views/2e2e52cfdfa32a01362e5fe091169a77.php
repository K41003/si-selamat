<p>Kepala Desa Tanjung Selamat Kecamatan Sunggal Kabupaten Deli Serdang dengan ini menerangkan&nbsp;bahwa&nbsp;:</p>
<?php echo $__env->make('surat.templates._bio', ['rows' => [
    'Nama Lengkap' => $w->nama,
    'Tempat/Tanggal Lahir' => $ttl,
    'NIK' => $w->nik,
    'Jenis Kelamin' => $w->jenis_kelamin,
    'Bangsa / Agama' => 'Indonesia / '.$w->agama,
    'Status' => $w->status_perkawinan,
    'Pekerjaan' => $w->pekerjaan,
    'Alamat' => $w->alamat.($w->rt || $w->rw ? ' RT '.($w->rt ?? '-').' / RW '.($w->rw ?? '-') : ''),
]], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<p>Nama tersebut di atas benar Penduduk Desa Tanjung Selamat Kecamatan Sunggal Kabupaten Deli Serdang, dan menurut sepengetahuan kami memang benar nama tersebut di atas berasal dari <b>Keluarga Kurang Mampu/Miskin</b>.</p>
<p>Surat Keterangan ini dibuat atas permintaan yang bersangkutan guna untuk melengkapi persyaratan administrasi <?php echo $v('keperluan', '.................'); ?></p>
<p>Demikianlah Surat Keterangan ini diperbuat dengan sebenarnya untuk dapat dipergunakan seperlunya.</p>
<?php echo $__env->make('surat.templates._ttd', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php /**PATH C:\7SIA3\Project_Web\si-selamat\si-selamat\resources\views/surat/templates/sktm.blade.php ENDPATH**/ ?>