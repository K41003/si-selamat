<!DOCTYPE html>
<html lang="id" class="h-full">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title><?php echo $__env->yieldContent('title', 'Dashboard'); ?> — SI SELAMAT · Desa Tanjung Selamat</title>
    <link rel="icon" type="image/png" href="<?php echo e(asset('images/logo-deli-serdang-sm.png')); ?>">

    
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
</head>
<body class="min-h-full flex flex-col bg-surface">
    <a href="#konten-utama" class="sr-only focus:not-sr-only focus:fixed focus:left-4 focus:top-4 focus:z-50 focus:rounded-control focus:bg-surface focus:px-4 focus:py-2 focus:text-sm focus:font-semibold focus:text-brand-700 focus:shadow-lg no-print">Lewati ke konten utama</a>

    <?php
        $isKades = auth()->check() && auth()->user()->isKades();
        $pendingCount = $isKades ? \App\Models\Surat::where('status', 'diajukan')->count() : 0;

        // [label, url, aktif?]
        $menu = [
            ['Dashboard',     route('dashboard'),     request()->routeIs('dashboard')],
            ['Data Warga',    route('warga.index'),   request()->routeIs('warga.*')],
            ['Daftar Surat',  route('surat.index'),   request()->routeIs('surat.index') || request()->routeIs('surat.show')],
            ['Buat Surat',    route('surat.create'),  request()->routeIs('surat.create')],
        ];
        if ($isKades) {
            $menu[] = ['Validasi Kades', route('validasi.index'), request()->routeIs('validasi.*')];
        }
        $menu[] = ['Log Aktivitas', route('logs.index'), request()->routeIs('logs.*')];
    ?>

    <div class="flex min-h-screen flex-col">
        <div class="app-shell">
            <header class="no-print z-40 border-b border-line bg-surface xl:sticky xl:top-0">
                
                <div class="flex flex-wrap items-center gap-x-4 pr-4 sm:pr-8 xl:flex-nowrap xl:gap-x-6">
                    <a href="<?php echo e(route('dashboard')); ?>" class="tab-logo group flex min-h-20 items-center gap-3 pl-5 pr-8 sm:pl-8">
                        <img src="<?php echo e(asset('images/logo-deli-serdang-sm.png')); ?>" width="40" height="40" alt="Logo Kabupaten Deli Serdang" class="size-10 shrink-0 object-contain transition-transform group-hover:scale-105">
                        <span class="leading-tight">
                            <span class="block text-lg font-extrabold tracking-tight text-brand-900">SI SELAMAT</span>
                            <span class="hidden text-xs text-ink-600 sm:block">Desa Tanjung Selamat</span>
                        </span>
                    </a>

                    <?php if(auth()->guard()->check()): ?>
                    <div class="ml-auto flex items-center gap-4 py-2 xl:order-last">
                        <div class="hidden text-right leading-tight md:block">
                            <p class="max-w-[13rem] text-sm font-semibold leading-snug text-ink-900 2xl:max-w-none 2xl:whitespace-nowrap" title="<?php echo e(auth()->user()->active_staff_name ?: auth()->user()->name); ?>"><?php echo e(auth()->user()->active_staff_name ?: auth()->user()->name); ?></p>
                            <p class="text-xs text-ink-600"><?php echo e(auth()->user()->role === 'kades' ? 'Kepala Desa' : 'Staf Pelayanan'); ?></p>
                        </div>
                        <form method="POST" action="<?php echo e(route('logout')); ?>">
                            <?php echo csrf_field(); ?>
                            <button type="submit" class="btn btn-secondary btn-sm">
                                <?php if (isset($component)) { $__componentOriginalce262628e3a8d44dc38fd1f3965181bc = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.icon','data' => ['name' => 'logout','class' => 'size-4']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'logout','class' => 'size-4']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $attributes = $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $component = $__componentOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?>
                                Keluar
                            </button>
                        </form>
                    </div>
                    <?php endif; ?>

                    <nav aria-label="Menu utama" class="relative order-last flex w-full gap-1 overflow-x-auto px-5 pb-3 [scrollbar-width:none] [&::-webkit-scrollbar]:hidden sm:px-3 xl:order-none xl:w-auto xl:flex-1 xl:justify-center xl:px-0 xl:pb-0">
                        <?php $__currentLoopData = $menu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as [$label, $url, $active]): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <a href="<?php echo e($url); ?>" <?php if($active): ?> aria-current="page" <?php endif; ?> class="pill-tab">
                            <?php echo e($label); ?>

                            <?php if($label === 'Validasi Kades' && $pendingCount > 0): ?>
                            <span class="rounded-full bg-gold-400 px-2 text-xs font-bold text-brand-900"><?php echo e($pendingCount); ?><span class="sr-only"> surat menunggu</span></span>
                            <?php endif; ?>
                        </a>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </nav>
                </div>
            </header>

            <main id="konten-utama" tabindex="-1" class="mx-auto w-full max-w-7xl flex-1 px-4 py-6 focus:outline-none sm:px-6 lg:px-8 lg:py-8 animate-fade-in">
                <?php if(session('success')): ?>
                <div role="status" class="mb-6 flex items-start gap-3 rounded-control border border-success-700/30 bg-success-100/60 p-4 text-sm text-success-800 no-print animate-slide-down">
                    <?php if (isset($component)) { $__componentOriginalce262628e3a8d44dc38fd1f3965181bc = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.icon','data' => ['name' => 'check-circle','class' => 'mt-0.5 size-5 shrink-0']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'check-circle','class' => 'mt-0.5 size-5 shrink-0']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $attributes = $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $component = $__componentOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?>
                    <span><?php echo e(session('success')); ?></span>
                </div>
                <?php endif; ?>

                <?php if(session('error')): ?>
                <div role="alert" class="mb-6 flex items-start gap-3 rounded-control border border-danger-700/30 bg-danger-100/60 p-4 text-sm text-danger-800 no-print animate-slide-down">
                    <?php if (isset($component)) { $__componentOriginalce262628e3a8d44dc38fd1f3965181bc = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.icon','data' => ['name' => 'exclamation','class' => 'mt-0.5 size-5 shrink-0']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'exclamation','class' => 'mt-0.5 size-5 shrink-0']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $attributes = $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $component = $__componentOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?>
                    <span><?php echo e(session('error')); ?></span>
                </div>
                <?php endif; ?>

                <?php echo $__env->yieldContent('content'); ?>
            </main>

            <footer class="py-5 text-center text-xs text-ink-600 no-print">
            &copy; <?php echo e(date('Y')); ?> SI SELAMAT &bull; Kantor Kepala Desa Tanjung Selamat, Kecamatan Sunggal, Kabupaten Deli Serdang.
        </footer>
        </div>

    </div>
</body>
</html>
<?php /**PATH C:\7SIA3\Project_Web\si-selamat\si-selamat\resources\views/layouts/app.blade.php ENDPATH**/ ?>